import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import scanRoutes from "./routes/scan.routes";

import authRoutes from "./routes/auth.routes";
import healthRoutes from "./routes/health.routes";
import submissionRoutes from "./routes/submission.routes";

import {
  notFound,
  errorHandler
} from "./middleware/error.middleware";

const app = express();

// Security headers
app.use(helmet());

// Frontend connection
app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    methods: ["GET", "POST", "PATCH", "DELETE"],
    allowedHeaders: [
      "Content-Type",
      "Authorization"
    ]
  })
);

// Request body parsing
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({
  extended: true,
  limit: "20kb"
}));

// API rate limiting
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 100,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: {
    success: false,
    message: "Too many requests. Please try again later."
  }
});

app.use("/api", apiLimiter);

// API routes
app.use("/api/health", healthRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/scans", scanRoutes);
app.use("/api/submissions", submissionRoutes);

// Error handling
app.use(notFound);
app.use(errorHandler);

export default app;